@echo off
chcp 65001 >nul
cd /d "%~dp0"
echo Установка зависимостей...
py -m pip install --upgrade pip
py -m pip install -r requirements.txt
echo Сборка 60x Cursor.exe...
py -m PyInstaller --noconfirm --clean --onefile --windowed --name "60x Cursor" --icon 60x_cursor.ico --add-data "60x_cursor.ico;." --collect-all PIL 60x_cursor.pyw
echo.
echo Готово! EXE находится в папке dist\
pause
