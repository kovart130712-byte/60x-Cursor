import os, sys, json, struct, ctypes, winreg, tkinter as tk
from tkinter import ttk, messagebox, colorchooser
from pathlib import Path
from PIL import Image, ImageDraw, ImageTk

APP_NAME = '60x Cursor'
DEFAULT_SIZE = 32
PALETTE = [('#000000','Чёрный'),('#FFFFFF','Белый'),('#FF0000','Красный'),('#800000','Бордовый'),('#00FF00','Зелёный'),('#0000FF','Синий'),('#FFFF00','Жёлтый'),('#FF00FF','Пурпурный'),('#00FFFF','Бирюзовый'),('#808080','Серый'),('#FFA500','Оранжевый'),('#800080','Фиолетовый')]
CURSOR_REG = r'Control Panel\Cursors'
SPI_SETCURSORS = 0x0057


def app_dir():
    base = os.environ.get('LOCALAPPDATA', str(Path.home()))
    p = Path(base) / '60xCursor'
    p.mkdir(parents=True, exist_ok=True)
    return p


def valid_hex(s):
    s = s.strip()
    if len(s) == 7 and s[0] == '#':
        try: int(s[1:], 16); return s.upper()
        except ValueError: pass
    return None


def draw_cursor(kind, size, fill, outline, border):
    # Draw at high resolution, then downsample once for clean anti-aliased edges.
    scale = 6
    n = int(size) * scale
    im = Image.new('RGBA', (n, n), (0, 0, 0, 0))
    d = ImageDraw.Draw(im)
    w = max(scale, int(border) * scale)
    if kind == 'arrow':
        pts = [(int(n*.12), int(n*.06)), (int(n*.12), int(n*.83)),
               (int(n*.34), int(n*.63)), (int(n*.49), int(n*.94)),
               (int(n*.64), int(n*.87)), (int(n*.49), int(n*.57)),
               (int(n*.80), int(n*.57))]
        d.polygon(pts, fill=fill)
        d.line(pts + [pts[0]], fill=outline, width=w, joint='curve')
        hx, hy = max(1, int(size*.12)), max(1, int(size*.06))
    else:
        pts = [(int(n*.36),int(n*.92)),(int(n*.24),int(n*.78)),
               (int(n*.13),int(n*.60)),(int(n*.14),int(n*.53)),
               (int(n*.20),int(n*.50)),(int(n*.34),int(n*.63)),
               (int(n*.35),int(n*.19)),(int(n*.39),int(n*.10)),
               (int(n*.46),int(n*.12)),(int(n*.49),int(n*.18)),
               (int(n*.49),int(n*.53)),(int(n*.55),int(n*.42)),
               (int(n*.63),int(n*.42)),(int(n*.66),int(n*.49)),
               (int(n*.69),int(n*.45)),(int(n*.77),int(n*.47)),
               (int(n*.80),int(n*.55)),(int(n*.83),int(n*.53)),
               (int(n*.91),int(n*.57)),(int(n*.92),int(n*.66)),
               (int(n*.84),int(n*.82)),(int(n*.72),int(n*.94))]
        d.polygon(pts, fill=fill)
        d.line(pts + [pts[0]], fill=outline, width=w, joint='curve')
        hx, hy = int(size*.39), int(size*.12)
    im = im.resize((int(size), int(size)), Image.Resampling.LANCZOS)
    return im, hx, hy


def write_cur(path, image, hx, hy):
    """Write a broadly compatible 32-bit DIB-based Windows .cur file.

    PNG payloads inside CUR files are not handled consistently by every
    cursor-loading path. A classic BITMAPINFOHEADER + BGRA XOR bitmap + AND
    mask works reliably with Windows 10.
    """
    width, height = image.size
    if not (1 <= width <= 255 and 1 <= height <= 255):
        raise ValueError('Размер курсора должен быть от 1 до 255 пикселей.')
    rgba = image.convert('RGBA')
    pixels = rgba.load()
    xor_rows = bytearray()
    # DIB pixel rows are stored bottom-up, in BGRA order.
    for y in range(height - 1, -1, -1):
        for x in range(width):
            r, g, b, a = pixels[x, y]
            xor_rows.extend((b, g, r, a))
    # 1-bit transparency mask, DWORD-aligned. Zero means the XOR pixel is used.
    mask_stride = ((width + 31) // 32) * 4
    and_mask = bytes(mask_stride * height)
    image_size = len(xor_rows) + len(and_mask)
    header = struct.pack('<IiiHHIIiiII', 40, width, height * 2, 1, 32,
                         0, image_size, 0, 0, 0, 0)
    dib = header + bytes(xor_rows) + and_mask
    directory = struct.pack('<HHH', 0, 2, 1)
    entry = struct.pack('<BBBBHHII', width if width < 256 else 0,
                        height if height < 256 else 0, 0, 0,
                        max(0, min(width - 1, int(hx))),
                        max(0, min(height - 1, int(hy))), len(dib), 22)
    Path(path).write_bytes(directory + entry + dib)


class App:
    def __init__(self, root):
        self.root = root
        root.title('60x Cursor — настройка курсора')
        root.geometry('760x700'); root.minsize(700,650)
        self.fill = tk.StringVar(value='#000000')
        self.edge = tk.StringVar(value='#FF3030')
        self.size = tk.IntVar(value=DEFAULT_SIZE)
        self.border = tk.IntVar(value=2)
        self.status = tk.StringVar(value='Настрой внешний вид курсора и нажми «Применить».')
        self._preview = []
        self._build(); self.refresh()

    def _build(self):
        style=ttk.Style(); style.theme_use('clam')
        style.configure('TFrame', background='#171923'); style.configure('TLabel', background='#171923', foreground='#F3F4F6', font=('Segoe UI',10))
        style.configure('Title.TLabel',font=('Segoe UI',20,'bold'),foreground='#FFFFFF')
        style.configure('Sub.TLabel',foreground='#AAB0C0')
        style.configure('TButton',font=('Segoe UI',10),padding=7)
        self.root.configure(bg='#171923')
        outer=ttk.Frame(self.root,padding=22); outer.pack(fill='both',expand=True)
        ttk.Label(outer,text='60x Cursor',style='Title.TLabel').pack(anchor='w')
        ttk.Label(outer,text='Настройка стрелки и руки одним набором параметров',style='Sub.TLabel').pack(anchor='w',pady=(2,16))
        top=ttk.Frame(outer); top.pack(fill='x')
        preview=ttk.Frame(top,padding=14); preview.pack(side='left',fill='y')
        ttk.Label(preview,text='ПРЕДПРОСМОТР').pack(anchor='w')
        self.canvas=tk.Canvas(preview,width=220,height=205,bg='#252A38',highlightthickness=0)
        self.canvas.pack(pady=(8,4))
        ttk.Label(preview,text='Стрелка и рука используют\nодинаковые цвета и размер',style='Sub.TLabel',justify='center').pack()
        controls=ttk.Frame(top,padding=(20,4,0,0)); controls.pack(side='left',fill='both',expand=True)
        self._color_control(controls,'Цвет заполнения',self.fill)
        self._color_control(controls,'Цвет границ',self.edge)
        ttk.Label(controls,text='Толщина границ').pack(anchor='w',pady=(12,0))
        ttk.Scale(controls,from_=1,to=8,orient='horizontal',variable=self.border,command=lambda v:self._set_border(v)).pack(fill='x')
        self.border_label=ttk.Label(controls,text='2 px',style='Sub.TLabel'); self.border_label.pack(anchor='w')
        ttk.Label(controls,text='Размер курсора').pack(anchor='w',pady=(14,0))
        ttk.Scale(controls,from_=16,to=96,orient='horizontal',variable=self.size,command=lambda v:self._set_size(v)).pack(fill='x')
        self.size_label=ttk.Label(controls,text=f'{DEFAULT_SIZE} px',style='Sub.TLabel'); self.size_label.pack(anchor='w')
        row=ttk.Frame(controls); row.pack(fill='x',pady=(12,0))
        ttk.Button(row,text='По умолчанию',command=self.reset_size).pack(side='left')
        ttk.Button(row,text='Выбрать цвет…',command=self.pick_fill).pack(side='left',padx=8)
        ttk.Separator(outer).pack(fill='x',pady=18)
        ttk.Label(outer,text='ГОТОВАЯ ПАЛИТРА').pack(anchor='w')
        palette=ttk.Frame(outer); palette.pack(fill='x',pady=10)
        for i,(color,name) in enumerate(PALETTE):
            b=tk.Button(palette,bg=color,activebackground=color,relief='flat',width=4,height=1,command=lambda c=color:self.set_fill(c),cursor='hand2')
            b.grid(row=i//6,column=i%6,padx=5,pady=5,sticky='ew')
        for i in range(6): palette.columnconfigure(i,weight=1)
        hexrow=ttk.Frame(outer); hexrow.pack(fill='x',pady=(4,10))
        ttk.Label(hexrow,text='Свой HEX-цвет заливки').pack(side='left')
        self.hex_entry=ttk.Entry(hexrow,textvariable=self.fill,width=12); self.hex_entry.pack(side='left',padx=10)
        self.hex_entry.bind('<KeyRelease>',lambda e:self.refresh())
        ttk.Label(hexrow,text='Формат: #800000',style='Sub.TLabel').pack(side='left')
        ttk.Label(outer,text='Цвет границ HEX').pack(anchor='w')
        edge_row=ttk.Frame(outer); edge_row.pack(fill='x',pady=(4,8))
        self.edge_entry=ttk.Entry(edge_row,textvariable=self.edge,width=12); self.edge_entry.pack(side='left')
        self.edge_entry.bind('<KeyRelease>',lambda e:self.refresh())
        ttk.Label(edge_row,text='Например: #FF0000',style='Sub.TLabel').pack(side='left',padx=10)
        actions=ttk.Frame(outer); actions.pack(fill='x',pady=(10,0))
        ttk.Button(actions,text='Применить курсор',command=self.apply).pack(side='left')
        ttk.Button(actions,text='Восстановить Windows',command=self.restore).pack(side='left',padx=10)
        ttk.Label(outer,textvariable=self.status,style='Sub.TLabel',wraplength=680).pack(anchor='w',pady=(12,0))

    def _color_control(self,parent,label,var):
        ttk.Label(parent,text=label).pack(anchor='w')
        row=ttk.Frame(parent); row.pack(fill='x',pady=(4,0))
        sw=tk.Label(row,text='   ',bg=var.get(),relief='solid',bd=1); sw.pack(side='left',ipady=7)
        ttk.Label(row,textvariable=var,width=12).pack(side='left',padx=8)
        ttk.Button(row,text='Выбрать…',command=(self.pick_fill if var is self.fill else self.pick_edge)).pack(side='left')
        if var is self.fill: self.fill_swatch=sw
        else: self.edge_swatch=sw

    def _set_border(self,v): self.border.set(round(float(v))); self.border_label.config(text=f'{self.border.get()} px'); self.refresh()
    def _set_size(self,v): self.size.set(round(float(v))); self.size_label.config(text=f'{self.size.get()} px'); self.refresh()
    def reset_size(self): self.size.set(DEFAULT_SIZE); self.size_label.config(text=f'{DEFAULT_SIZE} px'); self.refresh()
    def set_fill(self,c): self.fill.set(c); self.refresh()
    def pick_fill(self):
        c=colorchooser.askcolor(self.fill.get(),title='Цвет заполнения')[1]
        if c: self.fill.set(c.upper()); self.refresh()
    def pick_edge(self):
        c=colorchooser.askcolor(self.edge.get(),title='Цвет границ')[1]
        if c: self.edge.set(c.upper()); self.refresh()

    def refresh(self):
        f,e=valid_hex(self.fill.get()),valid_hex(self.edge.get())
        if hasattr(self,'fill_swatch'):
            if f: self.fill_swatch.configure(bg=f)
            if e: self.edge_swatch.configure(bg=e)
        if not f or not e: return
        self.canvas.delete('all')
        for kind,x in [('arrow',48),('hand',142)]:
            im,hx,hy=draw_cursor(kind, max(16,min(96,self.size.get())),f,e,self.border.get())
            tkimg=ImageTk.PhotoImage(im)
            self._preview.append(tkimg)
            self.canvas.create_image(x,90,image=tkimg,anchor='center')
            self.canvas.create_text(x,175,text=('Стрелка' if kind=='arrow' else 'Рука'),fill='#D7DBE7',font=('Segoe UI',9))
        self.canvas.create_text(110,198,text=f'Заливка {f}   •   Граница {e}',fill='#AAB0C0',font=('Segoe UI',8))

    def apply(self):
        f,e=valid_hex(self.fill.get()),valid_hex(self.edge.get())
        if not f or not e:
            messagebox.showerror('Неверный HEX','Введите цвет в формате #RRGGBB, например #800000.'); return
        try:
            folder=app_dir()
            for kind in ('arrow','hand'):
                im,hx,hy=draw_cursor(kind,max(16,min(96,int(self.size.get()))),f,e,max(1,min(8,int(self.border.get()))))
                write_cur(folder/(kind+'.cur'),im,hx,hy)
            # Save the current user's original Arrow/Hand values once, so they can be restored.
            backup=folder/'backup.json'
            if not backup.exists():
                data={}
                with winreg.OpenKey(winreg.HKEY_CURRENT_USER,CURSOR_REG) as k:
                    for name in ('Arrow','Hand'):
                        try: data[name]=winreg.QueryValueEx(k,name)[0]
                        except FileNotFoundError: data[name]=None
                backup.write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding='utf-8')
            with winreg.OpenKey(winreg.HKEY_CURRENT_USER,CURSOR_REG,0,winreg.KEY_SET_VALUE) as k:
                winreg.SetValueEx(k,'Arrow',0,winreg.REG_EXPAND_SZ,str(folder/'arrow.cur'))
                winreg.SetValueEx(k,'Hand',0,winreg.REG_EXPAND_SZ,str(folder/'hand.cur'))
            ctypes.windll.user32.SystemParametersInfoW(SPI_SETCURSORS, 0, None, 0x01 | 0x02)
            self.status.set('Готово! Стрелка и рука обновлены. Если изменения не появились сразу, выйди из системы и войди снова.')
            messagebox.showinfo('60x Cursor','Курсоры применены!')
        except Exception as ex:
            messagebox.showerror('Не удалось применить',f'{ex}\n\nПопробуй запустить приложение от имени пользователя Windows.')

    def restore(self):
        try:
            backup=app_dir()/'backup.json'
            if not backup.exists():
                messagebox.showinfo('Восстановление','Сначала нажми «Применить курсор», чтобы приложение сохранило исходные настройки Windows.'); return
            data=json.loads(backup.read_text(encoding='utf-8'))
            with winreg.OpenKey(winreg.HKEY_CURRENT_USER,CURSOR_REG,0,winreg.KEY_SET_VALUE) as k:
                for name,value in data.items():
                    if value is None:
                        try: winreg.DeleteValue(k,name)
                        except FileNotFoundError: pass
                    else: winreg.SetValueEx(k,name,0,winreg.REG_SZ,value)
            ctypes.windll.user32.SystemParametersInfoW(SPI_SETCURSORS, 0, None, 0x01 | 0x02)
            self.status.set('Исходные указатели Windows восстановлены.')
            messagebox.showinfo('60x Cursor','Стандартные курсоры Windows восстановлены.')
        except Exception as ex: messagebox.showerror('Ошибка',str(ex))


if __name__ == '__main__':
    if sys.platform != 'win32':
        print('Это приложение предназначено для Windows 10/11.')
    else:
        root=tk.Tk(); App(root); root.mainloop()
